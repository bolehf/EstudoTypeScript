export abstract class DioAccount{
    private readonly name : string 
    private readonly DioAccountNumber : number
    private balance: number = 0
    private status: boolean = true

    constructor (name : string, DioAccountNumber : number){
        this.name = name
        this.DioAccountNumber = DioAccountNumber
    }

    getName = (): string =>{
        return this.name
    }

    deposit = (value : number): void =>{
        this.balance += value
    }

    withdraw = (value : number): void =>{
        if(this.validateStatus()){
            if(value > this.balance){
                throw Error('Conta sem saldo suficiente!')
            }
            this.balance -= value
        }
    }

    getBalance = (): void => {
        console.log(this.balance)
    }

    setBalance = (emprestimo : number): void => {
        this.balance += emprestimo
    }

    validateStatus = (): boolean =>{
        if (this.status){
            return this.status
        }

        throw new Error('Conta inválida!')
    }
}