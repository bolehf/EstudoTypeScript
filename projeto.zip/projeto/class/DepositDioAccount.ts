import { DioAccount } from "./DioAccount"
//Herança
export class DepositDioAccount extends DioAccount {

    deposit = (value : number) =>{
        this.deposit(value + 10)
    }
}