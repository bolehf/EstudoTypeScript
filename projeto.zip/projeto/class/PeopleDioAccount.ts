import { DioAccount } from "./DioAccount"

//Herança
export class PeopleDioAccount extends DioAccount{
    doc_id : number

     constructor(doc_id : number, name : string, DioAccountNumber : number){
        super(name, DioAccountNumber)
        this.doc_id = doc_id
    }
}