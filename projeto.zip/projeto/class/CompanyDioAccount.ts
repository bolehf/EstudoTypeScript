import { DioAccount } from "./DioAccount"
//Herança
export class CompanyDioAccount extends DioAccount {

    constructor(name : string, DioAccountNumber : number){
        super(name, DioAccountNumber)
    }

    getLoan = (emprestimo : number): void => {
        this.withdraw(emprestimo)
        this.deposit(emprestimo)
        throw Error('Você não tem permissão para essa transação!')
    }
}
