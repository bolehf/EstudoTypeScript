import { CompanyDioAccount } from "./class/CompanyDioAccount"
import { PeopleDioAccount } from "./class/PeopleDioAccount"



const peopleDioAccount : PeopleDioAccount = new PeopleDioAccount(1, 'Nath', 10)

peopleDioAccount.getName()
console.log(peopleDioAccount)
console.log(peopleDioAccount.getName())
peopleDioAccount.deposit(300)