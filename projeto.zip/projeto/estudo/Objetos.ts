let b: string = 'b'
let n: number = 2
let x: boolean = true

//para receber mais de um tipo de valor
let m: string | number = 4
let h: boolean | number = true
let j: any = 'George'

h = false
const c = 'c'


//objetos

const objeto = {
    nome: 'Pessoa',
    idade: 34
}

interface Pessoa {
    nome: string,
    idade: number,
    profissao?: string //? = opcional
}

const pessoa : Pessoa = {
    nome: 'Robsu',
    idade: 1
}

const pessoa2 : Pessoa ={
    nome: "Claudio",
    idade: 1,
    profissao: 'Gato'
}

//Array
const arrayPessoa: Pessoa[] = [
    pessoa,
    pessoa2
]

const arrayPessoa2: Array<Pessoa> = [
    pessoa,
    pessoa2
]

const arrayNum: number[] =[
    1, 2, 3
]

const arrayString: string[] =[
    '1', '2', '3'
]