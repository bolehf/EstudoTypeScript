const array: Array<number> =[1, 2, 3]

const arrayString: string[] =['a', 'b', 'c']

//console.log(array[2], arrayString[0], array.length)
console.log(array, arrayString)

//adiciona elemento
array.push(4)

arrayString.push('d')

console.log(array, arrayString)

//remove elemento
//array.pop()

const buscaNum = array.find(num => num === 3)

array.map(x => {
    if(x > 2){
        console.log(x)
    }
})

console.log(buscaNum)