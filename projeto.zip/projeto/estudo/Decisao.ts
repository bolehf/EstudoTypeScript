import { validateHeaderName } from "http"

const num: number = 16


if(num > 15){
    console.log('Num maior que 15')
}else if (num === 15){
    console.log('Nume igual a 15')
}
else {
    console.log('Nume menor que 15')
}

const typeUser = {
    admin: 'Seja bem vindo, admin',
    student : 'Você é um estudante',
    viewer: 'Você pode visualizar'
}

function validaUser(user: string){
    console.log(typeUser[user as keyof typeof typeUser])
}

const usuario = 'viewer'

validaUser(usuario);