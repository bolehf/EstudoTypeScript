for(let i = 0; i < 5; i++){
    console.log(i)
}

for(let i = 0; i < 5; i+=2){
    console.log(i)
}

let n = 2

while(n < 6){
    console.log(n)
    n++
}